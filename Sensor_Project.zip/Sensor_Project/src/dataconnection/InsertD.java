package dataconnection;

import java.sql.*;
import java.util.*;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

/**
 * Servlet implementation class InsertD
 */
@WebServlet("/InsertD")
public class InsertD extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String contextRoot = "/Sensor_Project";

	String HOST = "sensor-database.ckxiqr8myjaj.us-west-2.rds.amazonaws.com";
	String PORT = "3306";
	String SCHEMA_NAME = "cloud_project_database";
	String CONNECTION_URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + SCHEMA_NAME + "?useSSL=false";
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InsertD() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		if (request.getParameter("addsensor1") != null) {
			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			Date currDate = new Date();
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
			String SENSORID = request.getParameter("sensorid");
			String BUSID = request.getParameter("busid");
			String SENSORNETWORKID = request.getParameter("sensornetworkid");
			String DATECREATED = dateFormat.format(currDate);
			String TIMECREATED = timeFormat.format(currDate);
			String Active = request.getParameter("optionsRadios");
			int i = 0;
			String temp;
			try {
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {

					String ins = "Insert into cloud_project_database.sensors(sensor_id,bus_id,sensor_network_id,date_created,time_created,Active) values(?,?,?,?,?,?)";
					PreparedStatement insStatement = null;
					insStatement = connection.prepareStatement(ins);
					insStatement.setString(1, SENSORID);
					insStatement.setString(2, BUSID);
					insStatement.setString(3, SENSORNETWORKID);
					insStatement.setString(4, DATECREATED);
					insStatement.setString(5, TIMECREATED);
					insStatement.setString(6, Active);
					System.out.println("Starting value of i=" + i);
					i = insStatement.executeUpdate();
					System.out.println("Value of i=" + i);

					connection.close();
					response.sendRedirect(contextRoot + "/html/AddSensors.jsp");

				}

			} catch (Exception ex) {
				System.out.println(ex);
				response.sendRedirect(contextRoot + "/html/AddSensors.jsp?e=t");
			
			}
		} else if (request.getParameter("addsensor2") != null) {
			try {

				String sen[]=request.getParameterValues("senid");
				System.out.println(sen);
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from sensors where sensor_id=7");
					int i = 0;
					while (i == 0) {
						String ins = "Update cloud_project_database.sensors set Active=true where sensor_id=7";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/AddSensors.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/AddSensors.jsp?e=t");

			}

		} else if (request.getParameter("addsensornetwork1") != null) {

			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			Date currDate = new Date();
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
			// String SENSORNETWORKID=request.getParameter("sensornetworkid");
			// String BUSID=request.getParameter("busid");
			String SENSORNETWORKID = request.getParameter("sensornetworkid");
			String DATECREATED = dateFormat.format(currDate);
			// String TIMECREATED=timeFormat.format(currDate);
			String Active = request.getParameter("optionsRadios");
			int i = 0;
			String temp;
			try {
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {

					String ins = "Insert into cloud_project_database.sensor_network(sensor_network_id,date_created,Active) values(?,?,?)";
					PreparedStatement insStatement = null;
					insStatement = connection.prepareStatement(ins);
					insStatement.setString(1, SENSORNETWORKID);
					insStatement.setString(2, DATECREATED);
					// insStatement.setString(3, SENSORNETWORKID);
					// insStatement.setString(4, DATECREATED);
					// insStatement.setString(5, TIMECREATED);
					insStatement.setString(3, Active);
					System.out.println("Starting value of i=" + i);
					i = insStatement.executeUpdate();
					System.out.println("Value of i=" + i);

					connection.close();
					response.sendRedirect(contextRoot + "/html/AddSensorNetwork.jsp");
				}

			} catch (Exception ex) {
				System.out.println(ex);
				response.sendRedirect(contextRoot + "/html/AddSensorNetwork.jsp?e=t");

			}

		} else if (request.getParameter("addsensornetwork2") != null) {

			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from sensor_network where sensor_network_id=4");
					int i = 0;
					while (i == 0) {
						String ins = "Update cloud_project_database.sensor_network set Active=true where sensor_network_id=6";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/AddSensorNetwork.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/AddSensorNetwork.jsp?e=t");
				
			}

		} else if (request.getParameter("addbus1") != null) {
			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			Date currDate = new Date();
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
			String BUSNO = request.getParameter("busno");
			String BUSID = request.getParameter("busid");
			String BUSLINE = request.getParameter("busline");
			String STARTSTOPID = request.getParameter("startstopid");
			String ENDSTOPID = request.getParameter("endstopid");
			String BUSNAME = request.getParameter("busname");
			String Active = request.getParameter("optionsRadios");
			int i = 0;
			String temp;
			try {
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {

					String ins = "Insert into cloud_project_database.bus_information(bus_id,bus_no,bus_line,starting_stop_id,ending_stop_id,bus_name,Active) values(?,?,?,?,?,?,?)";
					PreparedStatement insStatement = null;
					insStatement = connection.prepareStatement(ins);
					insStatement.setString(1, BUSID);
					insStatement.setString(2, BUSNO);
					insStatement.setString(3, BUSLINE);
					insStatement.setString(4, STARTSTOPID);
					insStatement.setString(5, ENDSTOPID);
					insStatement.setString(6, BUSNAME);
					insStatement.setString(7, Active);
					System.out.println("Starting value of i=" + i);
					i = insStatement.executeUpdate();
					System.out.println("Value of i=" + i);

					connection.close();
					response.sendRedirect(contextRoot + "/html/AddBus.jsp");
				}

			} catch (Exception ex) {
				System.out.println(ex);
				response.sendRedirect(contextRoot + "/html/AddBus.jsp?e=t");
				
			}
		} else if (request.getParameter("addbus2") != null) {
			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from bus_information where bus_id='57B'");
					int i = 0;
					while (i == 0) {
						String ins = "Update cloud_project_database.bus_information set Active=true where bus_id='57B'";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/AddBus.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/AddBus.jsp?e=t");
				
			}

		} else if (request.getParameter("addbusstop1") != null) {
			response.setContentType("text/html");
			PrintWriter pw = response.getWriter();
			Date currDate = new Date();
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
			DateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
			String BUSSTOPID = request.getParameter("busstopid");
			String BUSID = request.getParameter("busid");
			String STOPDISPLAYNAME = request.getParameter("stopdisplayname");
			String STOPORDER = request.getParameter("stoporder");
			String LONGITUDE = request.getParameter("longitude");
			String LATITUDE = request.getParameter("latitude");
			String SCHEDULETIME = request.getParameter("scheduletime");
			String Active = request.getParameter("optionsRadios");
			int i = 0;
			String temp;
			try {
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {

					String ins = "Insert into cloud_project_database.bus_stops(bus_stop_id,bus_id,stop_display_name,stop_order,longitude,latitude,schedule_time,Active) values(?,?,?,?,?,?,?,?)";
					PreparedStatement insStatement = null;
					insStatement = connection.prepareStatement(ins);
					insStatement.setString(1, BUSSTOPID);
					insStatement.setString(2, BUSID);
					insStatement.setString(3, STOPDISPLAYNAME);
					insStatement.setString(4, STOPORDER);
					insStatement.setString(5, LONGITUDE);
					insStatement.setString(6, LATITUDE);
					insStatement.setString(7, SCHEDULETIME);
					insStatement.setString(8, Active);
					System.out.println("Starting value of i=" + i);
					i = insStatement.executeUpdate();
					System.out.println("Value of i=" + i);

					connection.close();
					response.sendRedirect(contextRoot + "/html/AddBusStop.jsp");
				}

			} catch (Exception ex) {
				System.out.println(ex);
				response.sendRedirect(contextRoot + "/html/AddBusStop.jsp?e=t");
				
			}
		} else if (request.getParameter("addbusstop2") != null) {
			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from bus_stops where bus_stop_id=9");
					int i = 0;
					while (i == 0) {
						String ins = "Update cloud_project_database.bus_stops set Active=true where bus_stop_id=9";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/AddBusStop.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/AddBusStop.jsp?e=t");
				
			}

		} else if (request.getParameter("managesensor1") != null) {
			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from sensors where sensor_id=2");
					int i = 0;
					while (i == 0) {
						String ins = "delete from sensors where sensor_id=2";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/ManageSensors.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/ManageSensors.jsp?e=t");
				
			}

		} else if (request.getParameter("managesensornetwork1") != null) {
			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from sensor_network where sensor_network_id=6");
					int i = 0;
					while (i == 0) {
						String ins = "delete from sensor_network where sensor_network_id=6";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/ManageSensorNetworks.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/ManageSensorNetworks.jsp?e=t");
				
			}

		} else if (request.getParameter("managebuses1") != null) {
			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from bus_information where bus_id='57B'");
					int i = 0;
					while (i == 0) {
						String ins = "delete from bus_information where bus_id='57B'";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/ManageBuses.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/ManageBuses.jsp?e=t");
				
			}
		} else if (request.getParameter("managebusstop1") != null) {
			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from bus_stops where bus_stop_id=9");
					int i = 0;
					while (i == 0) {
						String ins = "delete from bus_stops where bus_stop_id=9";
						PreparedStatement insStatement = null;
						insStatement = connection.prepareStatement(ins);
						insStatement.executeUpdate();
						i++;
					}
					connection.close();
					response.sendRedirect(contextRoot + "/html/ManageBusStops.jsp");
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/ManageBusStops.jsp?e=t");
				
			}
		} else if (request.getParameter("login") != null) {
			try {

				// String sen[]=request.getParameterValues("senid");
//				String connectionURL = "jdbc:mysql://localhost:3306/cloud_project_database";
				Connection connection = null;
				Class.forName("com.mysql.jdbc.Driver").newInstance();
				connection = DriverManager.getConnection(CONNECTION_URL, "root", "mysqlroot");
				String USERID = request.getParameter("email");
				String PASSWORD = request.getParameter("password");

				if (!connection.isClosed()) {
					Statement sel = connection.createStatement();
					ResultSet r = sel.executeQuery("select * from users where email_id=" + USERID);
					int i = 0;
					while (r.next()) {
						response.sendRedirect(contextRoot + "/html/Dashboard.jsp");
					}
					connection.close();
				}
			} catch (Exception ex) {
				System.out.println(ex.toString());
				response.sendRedirect(contextRoot + "/html/Dashboard.jsp?e=t");
				
			}
		}

	}

}
