package com.sjsu.mapui;

import java.util.ArrayList;

public class NetworkLoadBalancer {

	private static Integer LAST_RETURNED_NETWORK_ID = null;
	
	/**
	 * We have implemented simple round robin algorithm to return to preferred network
	 * sensor id.This way load across all sensor networks is balanced equally. 
	 * @return
	 */
	public static Integer getNextPreferredNetworkId() {
		
		ArrayList<Integer> sensorNetworkIds = SensorDatabaseConnector.getActiveSensorsNetworkIds();
		
		boolean foundMatch = false;
		boolean assignedNetworkId = false;
		for(Integer currentNetworkId : sensorNetworkIds) {
			if(LAST_RETURNED_NETWORK_ID == null || foundMatch) {
				LAST_RETURNED_NETWORK_ID = currentNetworkId;
				assignedNetworkId = true;
				break;
			}
			
			if(LAST_RETURNED_NETWORK_ID.equals(currentNetworkId) ) {
				foundMatch = true;
			}
			
		}
		
		if(!assignedNetworkId) {
			LAST_RETURNED_NETWORK_ID = sensorNetworkIds.get(0);
		}
		
		return LAST_RETURNED_NETWORK_ID;
		
	}
}
