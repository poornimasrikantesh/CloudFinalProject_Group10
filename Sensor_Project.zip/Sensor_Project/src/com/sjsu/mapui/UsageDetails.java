package com.sjsu.mapui;

import java.sql.Date;

public class UsageDetails {

	String userName;
	int numberOfRequests;
	int numberOfSensors;	
	double bill;
	Date requestTime;
	public UsageDetails(String userName, int numberOfRequests, int numberOfSensors, double bill) {
		super();
		this.userName = userName;
		this.numberOfRequests = numberOfRequests;
		this.numberOfSensors = numberOfSensors;
		this.bill = bill;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getNumberOfRequests() {
		return numberOfRequests;
	}
	public void setNumberOfRequests(int numberOfRequests) {
		this.numberOfRequests = numberOfRequests;
	}
	public int getNumberOfSensors() {
		return numberOfSensors;
	}
	public void setNumberOfSensors(int numberOfSensors) {
		this.numberOfSensors = numberOfSensors;
	}
	public double getBill() {
		return bill;
	}
	public void setBill(double bill) {
		this.bill = bill;
	}
	public Date getRequestTime() {
		return requestTime;
	}
	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}
	
	
	
}
