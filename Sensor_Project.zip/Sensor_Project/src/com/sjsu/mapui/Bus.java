package com.sjsu.mapui;

import java.util.ArrayList;

public class Bus {

	String busNo;
	String busRouteName;
	int startingStopId;
	ArrayList<BusStop> busStops;

	public Bus(String busNo, String busRouteName, int startingStopId) {
		super();
		this.busNo = busNo;
		this.busRouteName = busRouteName;
		this.startingStopId = startingStopId;
	}

	public Bus(String busNo, String busRouteName, ArrayList<BusStop> busStops) {
		super();
		this.busNo = busNo;
		this.busRouteName = busRouteName;
		this.busStops = busStops;
	}
	public String getBusNo() {
		return busNo;
	}
	public void setBusNo(String busNo) {
		this.busNo = busNo;
	}
	public String getBusRouteName() {
		return busRouteName;
	}
	public void setBusRouteName(String busRouteName) {
		this.busRouteName = busRouteName;
	}
	public ArrayList<BusStop> getBusStops() {
		return busStops;
	}
	public void setBusStops(ArrayList<BusStop> busStops) {
		this.busStops = busStops;
	}

	public int getStartingStopId() {
		return startingStopId;
	}

	public void setStartingStopId(int startingStopId) {
		this.startingStopId = startingStopId;
	}
	
	
}
