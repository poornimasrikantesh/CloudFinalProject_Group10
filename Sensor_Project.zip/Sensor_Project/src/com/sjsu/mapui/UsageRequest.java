package com.sjsu.mapui;

import java.sql.Date;

public class UsageRequest {
	Date requestTime;
	String userNAme;
	String busId;
	int networkId;
	public UsageRequest(Date requestTime, String userNAme, String busId, int networkId) {
		super();
		this.requestTime = requestTime;
		this.userNAme = userNAme;
		this.busId = busId;
		this.networkId = networkId;
	}
	public Date getRequestTime() {
		return requestTime;
	}
	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}
	public String getUserNAme() {
		return userNAme;
	}
	public void setUserNAme(String userNAme) {
		this.userNAme = userNAme;
	}
	public String getBusId() {
		return busId;
	}
	public void setBusId(String busId) {
		this.busId = busId;
	}
	public int getNetworkId() {
		return networkId;
	}
	public void setNetworkId(int networkId) {
		this.networkId = networkId;
	}
	
	
}
