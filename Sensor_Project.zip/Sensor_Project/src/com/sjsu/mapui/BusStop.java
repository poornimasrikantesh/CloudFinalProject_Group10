package com.sjsu.mapui;

import java.sql.Time;
import java.util.HashMap;

public class BusStop {
	int busStopId;
	String busStopName;
	String arrivalTime;
	Time scheduleTime;
	boolean arrived;
	HashMap<String, Number> location = new HashMap<String, Number>();
	public BusStop(int busStopId, String busStopName) {
		super();
		this.busStopId = busStopId;
		this.busStopName = busStopName;
	}
	
	public BusStop(int busStopId, String busStopName, String lat, String lng) {
		super();
		this.busStopId = busStopId;
		this.busStopName = busStopName;
		location.put("lat", Double.parseDouble(lat));
		location.put("lng", Double.parseDouble(lng));
	}
	
	public BusStop(int busStopId, String busStopName, String lat, String lng, String arrivalTime, Time scheduleTime, boolean arrived) {
		super();
		this.busStopId = busStopId;
		this.busStopName = busStopName;
		location.put("lat", Double.parseDouble(lat));
		location.put("lng", Double.parseDouble(lng));
		this.arrivalTime = arrivalTime;
		this.arrived = arrived;
		this.scheduleTime = scheduleTime;
	}
	
	public int getBusStopId() {
		return busStopId;
	}
	public void setBusStopId(int busStopId) {
		this.busStopId = busStopId;
	}
	public String getBusStopName() {
		return busStopName;
	}
	public void setBusStopName(String busStopName) {
		this.busStopName = busStopName;
	}

	public HashMap<String,Number> getLocation() {
		return location;
	}

	public void setLocation(HashMap<String, Number> location) {
		this.location = location;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public boolean isArrived() {
		return arrived;
	}

	public void setArrived(boolean arrived) {
		this.arrived = arrived;
	}

	public Time getScheduleTime() {
		return scheduleTime;
	}

	public void setScheduleTime(Time scheduleTime) {
		this.scheduleTime = scheduleTime;
	}
	
	
}
