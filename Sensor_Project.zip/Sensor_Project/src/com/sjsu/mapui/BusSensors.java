package com.sjsu.mapui;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

/**
 * Servlet implementation class BusStatusRetriever
 */
@WebServlet("/bus-sensors")
public class BusSensors extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	SensorDatabaseConnector databaseConnector;
	ArrayList<BusStop> objBusStopList;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public BusSensors() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/json");
		
		String busId = request.getParameter("busId");
		String stopId = request.getParameter("stopId");
		
		// Apply Load Balancing and get preferred sensor network id
		
		Integer sensorNetworkId = NetworkLoadBalancer.getNextPreferredNetworkId();
		System.out.println("Sensor network Id obtained from load balancer - " + sensorNetworkId);
		ArrayList<Integer> busStops = databaseConnector.getSensorsForBus(busId, sensorNetworkId);
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonBusSensors = "";
		try {
			jsonBusSensors = mapper.writeValueAsString(busStops);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.setContentType("application/json");
		response.getWriter().append(jsonBusSensors);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
