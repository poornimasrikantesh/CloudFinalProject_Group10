package com.sjsu.mapui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

/**
 * Servlet implementation class BusDataRetriever
 */
@WebServlet("/businfo")
public class BusDataRetriever extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	SensorDatabaseConnector databaseConnector;
	ArrayList<Bus> objBusList;
	ArrayList<BusStop> objBusStopList;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BusDataRetriever() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<BusStop> busStops1 = new ArrayList<BusStop>();
		busStops1.add(new BusStop(1, "WEST VALLEY COLLEGE","37.267141", "-122.012314", "06:00 PM", null, true));
		busStops1.add(new BusStop(2, "SARATOGA AND CAMPBELL","37.292581", "-121.991052", "06:10 PM", null,  true));
		busStops1.add(new BusStop(3, "SARATOGA AND WILLIAMS","37.309165", "-121.977372", "06:15 PM", null, false));
		busStops1.add(new BusStop(4, "KIELY AND STEVENS CREEK","37.322868", "-121.975716","06:15 PM", null,  false));
		busStops1.add(new BusStop(5, "KIELY AND EL CAMINO REAL","37.352101", "-121.977800", "06:15 PM", null, false));

		Bus bus1 = new Bus("57", "West Valley to Great America", busStops1);

		ArrayList<BusStop> busStops2 = new ArrayList<BusStop>();
		busStops2.add(new BusStop(1, "Stop 1 -","37.359682", "-121.970302"));
		busStops2.add(new BusStop(2, "Stop 2 -","37.359682", "-121.970302"));
		busStops2.add(new BusStop(3, "Stop 3 -","37.359682", "-121.970302"));
		busStops2.add(new BusStop(4, "Stop 4 -","37.359682", "-121.970302"));

		Bus bus2 = new Bus("58", "West Valley to Santa Clara", busStops2);

		ArrayList<Bus> buses = new ArrayList<Bus>();
		buses.add(bus1);
		buses.add(bus2);
		
		// GEt all buses from database
		ArrayList<Bus> allBuses = databaseConnector.getAllRegisteredBuses();
		// For every bus find all of its stops  and set those stops in bus object
		
		for(Bus currentBus : allBuses) {
			ArrayList<BusStop> busStops = SensorDatabaseConnector.getAllBusStopsForBus(currentBus.getBusNo());
			
			currentBus.setBusStops(busStops);
		}
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonBuses = "";
		try {
			//jsonBuses = mapper.writeValueAsString(buses);
			jsonBuses = mapper.writeValueAsString(allBuses);
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.setContentType("application/json");
		response.getWriter().append(jsonBuses);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
