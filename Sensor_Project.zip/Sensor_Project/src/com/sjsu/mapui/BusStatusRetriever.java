package com.sjsu.mapui;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;

/**
 * Servlet implementation class BusStatusRetriever
 */
@WebServlet("/busstatus")
public class BusStatusRetriever extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	SensorDatabaseConnector databaseConnector;
	ArrayList<BusStop> objBusStopList;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public BusStatusRetriever() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/json");
		
		String busId = request.getParameter("busId");
		String stopId = request.getParameter("stopId");
		String sensorId = request.getParameter("sensorId");
		
		System.out.println("Bus id obatined -" + busId);
		System.out.println("Stop Id obatined -"+stopId);
		System.out.println("Sensor Id obatined -"+sensorId);
		
		
		// Insert the request in usage_request table
		Object objUsername = request.getSession().getAttribute("username");
		databaseConnector.registerRequest(objUsername.toString(), busId, stopId, sensorId);
		
		// DO the process or get data from database
		
		ArrayList<BusStop> busStops1 = new ArrayList<BusStop>();
		busStops1.add(new BusStop(1, "WEST VALLEY COLLEGE", "-122.012314", "37.267141", "13:00 PM", null, true));
		busStops1.add(new BusStop(2, "SARATOGA AND CAMPBELL", "-121.991052", "37.292581", "13:10 PM",null, true));
		busStops1.add(new BusStop(3, "SARATOGA AND WILLIAMS", "-121.977372","37.309165", "13:12 PM", null, false));
		busStops1.add(new BusStop(4, "KIELY AND STEVENS CREEK", "-121.975716", "37.322868","13:15 PM", null,  false));
		busStops1.add(new BusStop(5, "KIELY AND EL CAMINO REAL","-121.977800", "37.352101", "13:25 PM", null, false));
		
		
		ArrayList<BusStop> busStops = databaseConnector.getAllBusStopsForBusForArrivalTime(busId);
		
		ObjectMapper mapper = new ObjectMapper();
		String jsonBusStopStatus = "";
		try {
//			jsonBusStopStatus = mapper.writeValueAsString(busStops1);
			jsonBusStopStatus = mapper.writeValueAsString(busStops);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.setContentType("application/json");
		response.getWriter().append(jsonBusStopStatus);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
