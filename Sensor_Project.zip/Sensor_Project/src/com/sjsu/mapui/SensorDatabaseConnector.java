package com.sjsu.mapui;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;

import com.sjsu.mapui.Bus;
import com.sjsu.mapui.BusStop;

public class SensorDatabaseConnector {

	private static String HOST = "sensor-database.ckxiqr8myjaj.us-west-2.rds.amazonaws.com"; // "127.0.0.1";
	private static String PORT = "3306";
	private static String USERNAME = "root";
	private static String PASSWORD = "mysqlroot";
	private static String SCHEMA_NAME = "cloud_project_database";
	
	public static String CONNECTION_URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + SCHEMA_NAME + "?useSSL=false";
	
	public synchronized static ArrayList<Bus> getAllRegisteredBuses() {

		ArrayList<Bus> allBuses = new ArrayList<Bus>();
		Statement stmt = null;
		Connection connection = null;
		String query = "select bus_id, bus_no, bus_name, starting_stop_id, ending_stop_id from bus_information";
		try {
			connection = getDatabaseConnection();
			stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String busId = rs.getString("bus_id");
				int busNo = rs.getInt("bus_no");
				String busName = rs.getString("bus_name");
				int startingStopId = rs.getInt("starting_stop_id");
				int endingStopId = rs.getInt("ending_stop_id");
				System.out.println("Bus Record obtained " + busId + "--" + busNo + "--" + busName + "--"
						+ startingStopId + "--" + endingStopId);
				Bus bus = new Bus(busId, busName, startingStopId);
				allBuses.add(bus);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Number of bus object obtained from database - " + allBuses.size());
		return allBuses;
	}

	

	public synchronized static ArrayList<BusStop> getAllBusStopsForBus(String busId) {

		ArrayList<BusStop> allBusStops = new ArrayList<BusStop>();
		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select bus_stop_id, bus_id, stop_display_name, stop_order, longitude, latitude, schedule_time from bus_stops where bus_id = ? order by stop_order asc";
		
		System.out.println("quesry - " + query);
		
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
			stmt.setString(1, busId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int busStopId = rs.getInt("bus_stop_id");
				String dbBusId = rs.getString("bus_id");
				String stopDisplayName = rs.getString("stop_display_name");
				int stopOrder = rs.getInt("stop_order");
				String longitude = rs.getString("longitude");
				String latitude = rs.getString("latitude");
				Time scheduleTime = rs.getTime("schedule_time");

				System.out.println("Bus Stop Record obtained :: " + busStopId + ", " + dbBusId + ", " + stopDisplayName
						+ ", " + stopOrder + ", " + longitude + ", " + scheduleTime);

				BusStop busStop = new BusStop(busStopId, stopDisplayName);
				allBusStops.add(busStop);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Number of bus stops obtained from database - " + allBusStops.size());
		return allBusStops;
	}
	
	public synchronized static ArrayList<Integer> getActiveSensorsNetworkIds() {

		ArrayList<Integer> sensorNetworkIds = new ArrayList<Integer>();
		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select distinct a.sensor_network_id from sensors a, sensor_network b where a.sensor_network_id = b.sensor_network_id and a.Active = true and b.Active = true order by a.sensor_network_id asc";
		
		System.out.println("quesry - " + query);
		
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int sensorNetworkId = rs.getInt("sensor_network_id");
				sensorNetworkIds.add(sensorNetworkId);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Number of sensors networks from database - " + sensorNetworkIds.size());
		return sensorNetworkIds;
	}
	
	public synchronized static ArrayList<Integer> getSensorsForBus(String busId, Integer sensorNetworkId) {

		ArrayList<Integer> busSensors = new ArrayList<Integer>();
		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select sensor_id from sensors where bus_id = ? and sensor_network_id = ? and Active = true";
		
		System.out.println("quesry - " + query);
		
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
			stmt.setString(1, busId);
			stmt.setInt(2, sensorNetworkId);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int sensorId = rs.getInt("sensor_id");

				busSensors.add(sensorId);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Number of sensors obtained from database - " + busSensors.size());
		return busSensors;
	}

	public synchronized static ArrayList<BusStop> getAllBusStopsForBusForArrivalTime(String busId) {

		
		ArrayList<BusStop> allBusStops = new ArrayList<BusStop>();
		PreparedStatement startingStopStmt = null;
		PreparedStatement stmt = null;
		Connection connection = null;
		String staringStopQuery = "select a.starting_stop_id, max(b.arrival_time) arrival_time from bus_information a, current_bus_location b where a.bus_id = b.bus_id and a.starting_stop_id = b.bus_stop_id and a.bus_id = ? group by a.starting_stop_id";
		String query = "select a.bus_stop_id, a.bus_id, stop_display_name, stop_order, longitude, latitude, DATE_ADD(b.arrival_time, INTERVAL -4 HOUR) arrival_time, a.schedule_time from bus_stops a left join current_bus_location b on a.bus_id = b.bus_id and a.bus_stop_id = b.bus_stop_id  where a.bus_id = ? order by stop_order asc";
		
		System.out.println("###Starting Stop Query - " + staringStopQuery);
		System.out.println("####Qury - " + query);
		try {
			connection = getDatabaseConnection();
			
			startingStopStmt = connection.prepareStatement(staringStopQuery);
			startingStopStmt.setString(1, busId);
			ResultSet startingStopRs = startingStopStmt.executeQuery();
			int startintStopId;
			Time firstStopArrivalTime = null;
			if (startingStopRs.next()) {
				startintStopId = startingStopRs.getInt("starting_stop_id");
				firstStopArrivalTime = startingStopRs.getTime("arrival_time");
			}
			
			
			stmt = connection.prepareStatement(query);
			stmt.setString(1, busId);
			ResultSet rs = stmt.executeQuery();
			Time lastScheduleTime = null;
			Time lastArrivalTime = null;
			
			while (rs.next()) {
				int busStopId = rs.getInt("bus_stop_id");
				String dbBusId = rs.getString("bus_id");
				String stopDisplayName = rs.getString("stop_display_name");
				int stopOrder = rs.getInt("stop_order");
				String longitude = rs.getString("longitude");
				String latitude = rs.getString("latitude");
				Time arrivalTime = rs.getTime("arrival_time");
				Time scheduleTime = rs.getTime("schedule_time");
				
				
				
				if(arrivalTime == null || arrivalTime.equals(firstStopArrivalTime) || arrivalTime.after(firstStopArrivalTime) ) {
					BusStop busStop = new BusStop(busStopId, stopDisplayName, latitude, longitude, arrivalTime == null ? null : arrivalTime.toString(), scheduleTime, arrivalTime == null ? false: true);

					System.out.println("Created Bus Stop Object for Id " + busStopId + ", lastScheduleTime -" + lastScheduleTime + " , arrivalTime -"+ arrivalTime);
					long timeOfNextStop = 0;
					if(lastScheduleTime != null && arrivalTime == null) {
						// If arrival time is null means bus is not yet arrived, lets find the expected arrival time
						System.out.println("Arrival Tim is null , in if condition ");
						long timeDiffForNextStop = scheduleTime.getTime() - lastScheduleTime.getTime();
						timeOfNextStop = lastArrivalTime.getTime() + timeDiffForNextStop;
						busStop.setArrivalTime((new Time(timeOfNextStop)).toString());
						
					}
					
					lastScheduleTime = scheduleTime; 
					if(arrivalTime != null)
						lastArrivalTime = arrivalTime;
					else 
						lastArrivalTime = new Time(timeOfNextStop);
					
					allBusStops.add(busStop);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Number of bus stops obtained from database - " + allBusStops.size());
		return allBusStops;
	}
	
	public static void registerRequest(String userName, String busId, String busStopId, String sensorId) {
		Connection connection = getDatabaseConnection();
		PreparedStatement pStmt = null;
		try {
			Statement CreateStatement = connection.createStatement();
			String sql = "INSERT INTO cloud_project_database.usage_request (user_name, sensor_id, bus_id, bus_stop_id, request_time, cost) VALUES (?, ?, ?, ?, NOW(), 2);";
			pStmt = connection.prepareStatement(sql);
			pStmt.setString(1, userName);
			pStmt.setInt(2, Integer.parseInt(sensorId));
			pStmt.setString(3, busId);
			pStmt.setInt(4, Integer.parseInt(busStopId));
			pStmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pStmt != null) {
					pStmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}
		
	}
	
	public static UsageDetails getUsageAndBillDetailForUser(String userName)  {

		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select user_name, count(distinct sensor_id) requested_sensors, count(request_id) total_requests, sum(cost) bill from usage_request where user_name = '"+userName+"' group by user_name";
		System.out.println(query);
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
//			stmt.setString(1, userName);
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String dbUserName = rs.getString("user_name");
				int totalSensors = rs.getInt("requested_sensors");
				int totalRequests = rs.getInt("total_requests");
				double bill = rs.getDouble("bill");
				UsageDetails usage = new UsageDetails(dbUserName, totalRequests, totalSensors, bill);
				return usage;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		return null;
	}

	
	public static ArrayList<UsageDetails> getUsageAndBillDetailForAdmin()  {

		ArrayList<UsageDetails> allUsageDetails = new ArrayList<UsageDetails>();
		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select user_name, count(distinct sensor_id) requested_sensors, count(request_id) total_requests, sum(cost) bill from usage_request group by user_name";
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String dbUserName = rs.getString("user_name");
				int totalSensors = rs.getInt("requested_sensors");
				int totalRequests = rs.getInt("total_requests");
				double bill = rs.getDouble("bill");
				UsageDetails usage = new UsageDetails(dbUserName, totalRequests, totalSensors, bill);
				allUsageDetails.add(usage);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		return allUsageDetails;
	}

	public static ArrayList<UsageDetails> getAllUsageAndBillDetailForUser(String userName)  {

		ArrayList<UsageDetails> allUsageDetails = new ArrayList<UsageDetails>();
		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select user_name, DATE(request_time) req_day, count(distinct sensor_id) requested_sensors, count(request_id) total_requests, sum(cost) bill from usage_request where user_name = '"+userName+"' group by user_name, DATE(request_time)";
		System.out.println(query);
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				String dbUserName = rs.getString("user_name");
				Date requestDay = rs.getDate("req_day");
				int totalSensors = rs.getInt("requested_sensors");
				int totalRequests = rs.getInt("total_requests");
				double bill = rs.getDouble("bill");
				
				UsageDetails usage = new UsageDetails(dbUserName, totalRequests, totalSensors, bill);
				usage.setRequestTime(requestDay);
				allUsageDetails.add(usage);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Size - " + allUsageDetails.size());
		return allUsageDetails;
	}
	
	public static ArrayList<UsageDetails> getAllUsageOfAllUsers()  {

		ArrayList<UsageDetails> allUsageDetails = new ArrayList<UsageDetails>();
		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select DATE(request_time) req_day, count(distinct sensor_id) requested_sensors, count(request_id) total_requests, sum(cost) bill from usage_request group by DATE(request_time)";
		System.out.println(query);
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Date requestDay = rs.getDate("req_day");
				int totalSensors = rs.getInt("requested_sensors");
				int totalRequests = rs.getInt("total_requests");
				double bill = rs.getDouble("bill");
				
				UsageDetails usage = new UsageDetails("all_users", totalRequests, totalSensors, bill);
				usage.setRequestTime(requestDay);
				allUsageDetails.add(usage);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Size - " + allUsageDetails.size());
		return allUsageDetails;
	}
	
	public static ArrayList<UsageRequest> getAllUsageRequests()  {
		return getAllUsageRequests(false);
	}
	
	public static ArrayList<UsageRequest> getAllUsageRequests(boolean all)  {

		ArrayList<UsageRequest> allUsagerequests = new ArrayList<UsageRequest>();
		PreparedStatement stmt = null;
		Connection connection = null;
		String query = "select a.request_time, a.user_name, a.bus_id, b.sensor_network_id from usage_request a, sensors b where a.sensor_id = b.sensor_id "
				+ (all ? "" : "and request_time > DATE_ADD(NOW(),INTERVAL -30 DAY) " )
				+ "order by request_time desc";
		System.out.println(query);
		try {
			connection = getDatabaseConnection();
			stmt = connection.prepareStatement(query);
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				Date requestDay = rs.getDate("request_time");
				String userName = rs.getString("user_name");
				String busId = rs.getString("bus_id");
				int networkId = rs.getInt("sensor_network_id");
				
				UsageRequest usage = new UsageRequest(requestDay, userName, busId, networkId);
				allUsagerequests.add(usage);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				// DO NOTHING
			}
		}

		System.out.println("Size - " + allUsagerequests.size());
		return allUsagerequests;
	}
	
	public static Connection getDatabaseConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
//			System.out.println("MySQL JDBC Driver Registered!");
			Connection connection = DriverManager.getConnection("jdbc:mysql://" + HOST + ":" + PORT + "/" + SCHEMA_NAME + "?useSSL=false",
					USERNAME, PASSWORD);

			return connection;
		} catch (ClassNotFoundException e) {
			System.out.println("Where is your MySQL JDBC Driver?");
			e.printStackTrace();
			return null;

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return null;
		}
	}
}
