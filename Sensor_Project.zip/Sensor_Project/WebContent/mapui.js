var buses;

$( document ).ready(function() {
    console.log( "ready!" );
    	    
//Now that the doc is fully ready - populate the lists   
//Next comes the make
    
    $.getJSON("businfo", function(json){
    	buses = json;
    	
        var busnameoptions= "";
        for (var i = 0; i < buses.length; i++){
        	busnameoptions += "<option selected disabled hidden>Select the Bus Name</option>";
        	busnameoptions+= "<option value='" + buses[i].busNo + "'>" + buses[i].busNo + " - " + buses[i].busRouteName + "</option>";
        }
        $("#busSelection").html(busnameoptions);
    });
    
    var updateSelectVehicleBox = function(busName) {
        console.log('updating with',busName);
        
    	for (var k=0; k<buses.length;k++) {
    		if (buses[k].busNo === busName){
    	        var listItems= "";
    	        for (var i = 0; i < buses[k].busStops.length; i++){
    	            listItems+= "<option value='" + buses[k].busStops[i].busStopId + "'>" + buses[k].busStops[i].busStopName + "</option>";
    	        }
    	        $("select#stopSelection").html(listItems);    			
    		}
    	}
    }
   
    $('select#busSelection').on('change', function(){
        var selectedMake = $('#busSelection option:selected').val();
        $("#sensorButton").removeClass("disabled");
        $("#sensors").html('');
        updateSelectVehicleBox(selectedMake);
    });  
    
});


function handleClick(currentRadio) {
	$("#reqButton").removeClass("disabled");
}

var map;
function initMap() {

	var sanJoseLocation = { lat: 37.335342, lng: -121.893354 };
	 
	map = new google.maps.Map(document.getElementById('map'), {
		zoom : 12,
		center : sanJoseLocation,
		mapTypeId : google.maps.MapTypeId.ROADMAP
	});

}
var markers = [];

function addMarker(location, map, markerText, textColor, bounce) {
	var bounceValue = null;
	if (bounce === true) {
		bounceValue = google.maps.Animation.BOUNCE;
	}
	// Add the marker at the clicked location, and add the next-available label
	// from the array of alphabetical characters.
	var marker = new google.maps.Marker({
		position : location,
		label : {
			text : markerText,
			color : textColor,
			fontFamily : '"Arial", sans-serif',
			fontWeight : 'bold',
			fontSize : '14px'
		},
		// icon: {
		// path: google.maps.SymbolPath.CIRCLE,
		// scale: 3
		// },
		animation : bounceValue,
		map : map,
		shape : {
			type : 'rect'
		}
	});
	
	markers.push(marker);
}

function clearMarkers() {
	for (var i = 0; i < markers.length; i++) {
		markers[i].setMap(null);
	}
	markers = [];
}





function showAvailableSensors() {
	var selectedBusNo = $('#busSelection option:selected').val();
	var selectStopNo = $('#stopSelection option:selected').val();
	var busSensors;
    $.getJSON("bus-sensors?busId=" + selectedBusNo, function(json){
    	busSensors = json;
    	var resultHtml = '<label>Available Sensors : </label>&nbsp;';
    	for(var i =0 ;i < busSensors.length; i++) {
    		resultHtml += '<label class="radio-inline"><input type="radio" id="sensorradio" name="sensorradio" onclick="handleClick(this);" value="'+ busSensors[i] +'" >Sensor ' + busSensors[i] + '</label>';
    	}
    	resultHtml += '&nbsp;&nbsp;<button type="submit" id="reqButton" class="btn btn-primary disabled">Check Arrival Time</button>';
    	$("#sensors").html(resultHtml);
    });
}




function showBusStatus() {
	var selectedBusNo = $('#busSelection option:selected').val();
	var selectStopNo = $('#stopSelection option:selected').val();
	var selectedSensor = $('#sensorradio:checked').val();
	
	var busStopStatus;
	clearMarkers();
    $.getJSON("busstatus?busId=" + selectedBusNo + '&stopId='+selectStopNo + '&sensorId='+selectedSensor, function(json){
    	map.setZoom(11);
    	busStopStatus = json;
    	var resultHtml = '<table class="table-condensed table-bordered"><tr><th>Bus Stop Name</th><th>Arrived At</th><th>Estimated Arrival Time</th></tr>';
    	for(var i =0 ;i < busStopStatus.length; i++) {
    		var isActive = '';
    		if(busStopStatus[i].busStopId == selectStopNo) {
    			isActive = ' active ';
    			map.setCenter(busStopStatus[i].location);
    			map.setZoom(13);
    		}
    		
    		resultHtml += '<tr class="' + isActive + '"><td>' + busStopStatus[i].busStopName;
    		if(busStopStatus[i].arrived == true) {
    			resultHtml += '<td><span class="label label-success">' + busStopStatus[i].arrivalTime + '</span></td><td>-</td>';
    		} else {
    			resultHtml += '<td>-</td><td><span class="label label-warning">' + busStopStatus[i].arrivalTime + '</span></td>';
    		}
    		resultHtml += '</tr>';
    		addMarker(busStopStatus[i].location, map, busStopStatus[i].busStopName, busStopStatus[i].arrived ? 'green' : 'orange', (busStopStatus[i].busStopId == selectStopNo));	
    	}
    	resultHtml += '</table>';
    	$("#results").html(resultHtml);
    	$("#sensors").html('');

    });
}
function showBusStatus1() {
	var selectedBusNo = $('#busSelection option:selected').val();
	var selectStopNo = $('#stopSelection option:selected').val();
	
	
	var busStopStatus;
	clearMarkers();
    $.getJSON("busstatus?busId=" + selectedBusNo, function(json){
    	busStopStatus = json;
    	var resultHtml = '<ul class="list-group">';
    	for(var i =0 ;i < busStopStatus.length; i++) {
    		var isActive = '';
    		
    		//alert("PRocessing " + i + " busStopStatus[i].busStopId - " + busStopStatus[i].busStopId + ", and selected Stop - "+ selectStopNo);

    		if(busStopStatus[i].busStopId == selectStopNo) {
    			isActive = ' active ';
    			alert("lat - " + busStopStatus[i].location.lat+ ", lng - " + busStopStatus[i].location.lng);
    			map.setCenter(busStopStatus[i].location);
    			map.setZoom(13);
    		}
    		
    		resultHtml += '<li class="list-group-item ' + isActive + '">' + busStopStatus[i].busStopName + ' - ';
    		if(busStopStatus[i].arrived == true) {
    			resultHtml += '<span class="label label-success">' + busStopStatus[i].arrivalTime + '</span>';
    		} else {
    			resultHtml += '<span class="label label-warning"> Estimated Arrival - ' + busStopStatus[i].arrivalTime + '</span>';
    		}
    		resultHtml += '</li>';
    		addMarker(busStopStatus[i].location, map, busStopStatus[i].busStopName, busStopStatus[i].arrived ? 'green' : 'orange', (busStopStatus[i].busStopId == selectStopNo));	
    	}
    	resultHtml += '</ul>';
    	$("#results").html(resultHtml);
    	

    });
}